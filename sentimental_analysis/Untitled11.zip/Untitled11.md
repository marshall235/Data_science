```python
import pandas as pd
import numpy as np
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.sentiment import SentimentIntensityAnalyzer

```


```python
# Load the data from Excel
data = pd.read_excel('Airfryer.xlsx')
```


```python
df = data.sample(1000, random_state=0)
```


```python
# Text preprocessing
df['tokens'] = df['translatedText'].apply(lambda x: word_tokenize(str(x)) if pd.notnull(x) else [])
df['tokens'] = df['tokens'].apply(lambda x: [token.lower() for token in x])
```


```python
# Remove stopwords
stop_words = set(stopwords.words('english'))
df['tokens'] = df['tokens'].apply(lambda x: [token for token in x if token not in stop_words])
```


```python
# Sentiment analysis
sia = SentimentIntensityAnalyzer()
df['sentiment'] = df['translatedText'].apply(lambda x: sia.polarity_scores(str(x))['compound'])
```


```python
# Further analysis
average_sentiment = df['sentiment'].mean()
positive_reviews = df[df['sentiment'] > 0]
negative_reviews = df[df['sentiment'] < 0]
positive_count = len(positive_reviews)
negative_count = len(negative_reviews)
```


```python
print(average_sentiment)
print(positive_reviews)
print(negative_reviews)
print(positive_count)
print(negative_count)
```

    0.5156729
                                              translatedText       name   
    44677  Very good, the quality is really not comparabl...  Airfryers  \
    39682  I have received the Philips air fryer and I ha...  Airfryers   
    885    Purchased after various reflections, good prod...  Airfryers   
    73098  The pot is good, easy to operate and easy to l...  Airfryers   
    54108  Received the first roasted pork belly, very qu...  Airfryers   
    ...                                                  ...        ...   
    5395   As soon as I received it, I started to make de...  Airfryers   
    26905                                  it is recommended  Airfryers   
    65025  Much smaller than the oven, the capacity is in...  Airfryers   
    17387  I like it, the size is right, the appearance i...  Airfryers   
    29239  Doesn't need preheating, works great. Immediat...  Airfryers   
    
           Unnamed: 2                   sku country          channel  rating   
    44677         NaN  HD9270/91, HD9252/81   China           jd.com     5.0  \
    39682         NaN  HD9270/91, HD9252/81   China           jd.com     5.0   
    885           NaN             HD9280/90   Italy        amazon.it     3.0   
    73098         NaN  HD9215/81, HD9215/61   China       taobao.com     NaN   
    54108         NaN  HD9252/81, HD9252/51   China           jd.com     5.0   
    ...           ...                   ...     ...              ...     ...   
    5395          NaN             HD9257/70   China           jd.com     5.0   
    26905         NaN             HD9650/90  Turkey  hepsiburada.com     5.0   
    65025         NaN             HD9270/91   China        tmall.com     NaN   
    17387         NaN             HD9100/50   China           jd.com     5.0   
    29239         NaN  HD9252/81, HD9252/51   China        tmall.com     NaN   
    
          publishedByUserAt                                             tokens   
    44677        2022-06-05  [good, ,, quality, really, comparable, three, ...  \
    39682        2022-06-18  [received, philips, air, fryer, always, wanted...   
    885          2023-03-13  [purchased, various, reflections, ,, good, pro...   
    73098        2021-08-28  [pot, good, ,, easy, operate, easy, learn, ,, ...   
    54108        2022-04-08  [received, first, roasted, pork, belly, ,, qui...   
    ...                 ...                                                ...   
    5395         2023-01-30  [soon, received, ,, started, make, delicious, ...   
    26905        2022-09-03                                      [recommended]   
    65025        2021-11-23  [much, smaller, oven, ,, capacity, indeed, lar...   
    17387        2022-11-12  [like, ,, size, right, ,, appearance, really, ...   
    29239        2022-08-12  [n't, need, preheating, ,, works, great, ., im...   
    
           sentiment  
    44677     0.4927  
    39682     0.7650  
    885       0.2382  
    73098     0.9468  
    54108     0.4927  
    ...          ...  
    5395      0.9237  
    26905     0.2023  
    65025     0.6151  
    17387     0.3612  
    29239     0.9661  
    
    [748 rows x 10 columns]
                                               translatedText       name   
    94855   No need to fry things in the oil pan anymore, ...  Airfryers  \
    73640   Made an Orleans grilled chicken wing root, put...  Airfryers   
    65648   To be honest, I bought this one impulsively. I...  Airfryers   
    55563   The accessories are a bit ridiculous in my 5'5...  Airfryers   
    90972                  Philips air fryer is really tough.  Airfryers   
    ...                                                   ...        ...   
    64900          Usually it's useless once you buy it back.  Airfryers   
    107689  The product is really easy to use, but the log...  Airfryers   
    87024   After struggling for a long time, I finally ch...  Airfryers   
    9329    my recently purchased Philips Airfryer is easy...  Airfryers   
    106580  For us the first airfryer. Then you have plent...  Airfryers   
    
            Unnamed: 2                                                sku   
    94855          NaN                               HD9215/81, HD9215/61  \
    73640          NaN                               HD9215/81, HD9215/61   
    65648          NaN                    HD9741/11, HD9860/91, HD9741/61   
    55563          NaN                                          HD9270/70   
    90972          NaN  HD9741/61, HD9651/91, HD9741/11, HD9651/61, HD...   
    ...            ...                                                ...   
    64900          NaN                               HD9200/91, HD9200/21   
    107689         NaN                               HD9741/11, HD9651/61   
    87024          NaN                               HD9215/61, HD9215/81   
    9329           NaN                                          HD9270/70   
    106580         NaN                                          HD9650/90   
    
                country        channel  rating publishedByUserAt   
    94855         China     taobao.com     NaN        2020-06-24  \
    73640         China     taobao.com     NaN        2021-08-21   
    65648         China         jd.com     5.0        2021-11-18   
    55563         Spain      amazon.es     3.0        2022-03-25   
    90972         China     suning.com     5.0        2020-11-10   
    ...             ...            ...     ...               ...   
    64900         China         jd.com     4.0        2021-11-24   
    107689        China         jd.com     5.0        2019-01-16   
    87024         China     taobao.com     NaN        2021-01-21   
    9329    Netherlands     blokker.nl     5.0        2022-12-28   
    106580  Netherlands  mediamarkt.nl     3.0        2019-03-16   
    
                                                       tokens  sentiment  
    94855   [need, fry, things, oil, pan, anymore, ,, less...    -0.0737  
    73640   [made, orleans, grilled, chicken, wing, root, ...    -0.2513  
    65648   [honest, ,, bought, one, impulsively, ., used,...    -0.1531  
    55563   [accessories, bit, ridiculous, 5'5l, fryer, co...    -0.1901  
    90972             [philips, air, fryer, really, tough, .]    -0.2006  
    ...                                                   ...        ...  
    64900                [usually, 's, useless, buy, back, .]    -0.4215  
    107689  [product, really, easy, use, ,, logistics, bad...    -0.5652  
    87024   [struggling, long, time, ,, finally, chose, xi...    -0.5684  
    9329    [recently, purchased, philips, airfryer, easy,...    -0.0253  
    106580  [us, first, airfryer, ., plenty, questions, .,...    -0.6046  
    
    [61 rows x 10 columns]
    748
    61
    


```python
import matplotlib.pyplot as plt
```


```python
# Plotting
# Sentiment Distribution
plt.figure(figsize=(8, 6))
plt.hist(df['sentiment'], bins=20, color='skyblue', edgecolor='black')
plt.xlabel('Sentiment Score')
plt.ylabel('Frequency')
plt.title('Sentiment Distribution')
plt.show()
```


    
![png](output_9_0.png)
    



```python
# Sentiment Pie Chart
labels = ['Positive', 'Negative']
sizes = [positive_count, negative_count]
colors = ['lightgreen', 'lightcoral']
explode = (0.1, 0)  # explode the positive slice

plt.figure(figsize=(6, 6))
plt.pie(sizes, labels=labels, colors=colors, explode=explode, autopct='%1.1f%%', startangle=90)
plt.title('Sentiment Analysis')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.show()
```


    
![png](output_10_0.png)
    



```python

```
