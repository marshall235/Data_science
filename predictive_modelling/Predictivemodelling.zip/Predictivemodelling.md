```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.impute import SimpleImputer
import seaborn as sns
```


```python
# Load data
data = pd.read_excel("C:/Users/fredy/Desktop/Data.xlsx")
print(data.head())
```

      Ware_house_ID WH_Manager_ID Location_type WH_capacity_size   zone   
    0     WH_100000     EID_50000         Urban            Small   West  \
    1     WH_100001     EID_50001         Rural            Large  North   
    2     WH_100002     EID_50002         Rural              Mid  South   
    3     WH_100003     EID_50003         Rural              Mid  North   
    4     WH_100004     EID_50004         Rural            Large  North   
    
      WH_regional_zone  num_refill_req_l3m  transport_issue_l1y   
    0           Zone 6                   3                    1  \
    1           Zone 5                   0                    0   
    2           Zone 2                   1                    0   
    3           Zone 3                   7                    4   
    4           Zone 5                   3                    1   
    
       Competitor_in_mkt  retail_shop_num  ... electric_supply  dist_from_hub   
    0                  2             4651  ...               1             91  \
    1                  4             6217  ...               1            210   
    2                  4             4306  ...               0            161   
    3                  2             6000  ...               0            103   
    4                  2             4740  ...               1            112   
    
       workers_num  wh_est_year  storage_issue_reported_l3m  temp_reg_mach   
    0         29.0          NaN                          13              0  \
    1         31.0          NaN                           4              0   
    2         37.0          NaN                          17              0   
    3         21.0          NaN                          17              1   
    4         25.0       2009.0                          18              0   
    
       approved_wh_govt_certificate  wh_breakdown_l3m  govt_check_l3m   
    0                             A                 5              15  \
    1                             A                 3              17   
    2                             A                 6              22   
    3                            A+                 3              27   
    4                             C                 6              24   
    
       product_wg_ton  
    0           17115  
    1            5074  
    2           23137  
    3           22115  
    4           24071  
    
    [5 rows x 24 columns]
    


```python
# Check for missing values
missing_values = data.isna().sum()
print(missing_values)
```

    Ware_house_ID                       0
    WH_Manager_ID                       0
    Location_type                       0
    WH_capacity_size                    0
    zone                                0
    WH_regional_zone                    0
    num_refill_req_l3m                  0
    transport_issue_l1y                 0
    Competitor_in_mkt                   0
    retail_shop_num                     0
    wh_owner_type                       0
    distributor_num                     0
    flood_impacted                      0
    flood_proof                         0
    electric_supply                     0
    dist_from_hub                       0
    workers_num                       990
    wh_est_year                     11881
    storage_issue_reported_l3m          0
    temp_reg_mach                       0
    approved_wh_govt_certificate      908
    wh_breakdown_l3m                    0
    govt_check_l3m                      0
    product_wg_ton                      0
    dtype: int64
    


```python
# Handle missing values for 'wh_est_year'
median_wh_est_year = data['wh_est_year'].median()
data['wh_est_year'].fillna(median_wh_est_year, inplace=True)
```


```python
# Remove rows with missing values for 'product_wg_ton'
data.dropna(subset=['product_wg_ton'], inplace=True)
```


```python
# Convert categorical variables to appropriate data types
data['Ware_house_ID'] = data['Ware_house_ID'].astype('category')
data['WH_Manager_ID'] = data['WH_Manager_ID'].astype('category')
data['Location_type'] = data['Location_type'].astype('category')
data['zone'] = data['zone'].astype('category')
data['WH_regional_zone'] = data['WH_regional_zone'].astype('category')
data['wh_owner_type'] = data['wh_owner_type'].astype('category')
data['approved_wh_govt_certificate'] = data['approved_wh_govt_certificate'].astype('category')
```


```python
# Check for outliers using a box plot for 'product_wg_ton'
plt.figure()
plt.boxplot(data['product_wg_ton'])
plt.ylabel("Product Weight (tons)")
plt.title("Box Plot of Product Weight")
plt.show()
```


    
![png](output_6_0.png)
    



```python
########### EDA ###########
# Summary statistics for numerical variables
num_vars = ["num_refill_req_l3m", "dist_from_hub", "workers_num", "wh_est_year",
            "storage_issue_reported_l3m", "wh_breakdown_l3m", "govt_check_l3m", "product_wg_ton"]
print(data[num_vars].describe())
```

           num_refill_req_l3m  dist_from_hub   workers_num   wh_est_year   
    count        25000.000000   25000.000000  24010.000000  25000.000000  \
    mean             4.089040     163.537320     28.944398   2009.201080   
    std              2.606612      62.718609      7.872534      5.456731   
    min              0.000000      55.000000     10.000000   1996.000000   
    25%              2.000000     109.000000     24.000000   2009.000000   
    50%              4.000000     164.000000     28.000000   2009.000000   
    75%              6.000000     218.000000     33.000000   2010.000000   
    max              8.000000     271.000000     98.000000   2023.000000   
    
           storage_issue_reported_l3m  wh_breakdown_l3m  govt_check_l3m   
    count                25000.000000      25000.000000    25000.000000  \
    mean                    17.130440          3.482040       18.812280   
    std                      9.161108          1.690335        8.632382   
    min                      0.000000          0.000000        1.000000   
    25%                     10.000000          2.000000       11.000000   
    50%                     18.000000          3.000000       21.000000   
    75%                     24.000000          5.000000       26.000000   
    max                     39.000000          6.000000       32.000000   
    
           product_wg_ton  
    count    25000.000000  
    mean     22102.632920  
    std      11607.755077  
    min       2065.000000  
    25%      13059.000000  
    50%      22101.000000  
    75%      30103.000000  
    max      55151.000000  
    


```python
# Distribution of the target variable
plt.figure()
plt.hist(data['product_wg_ton'], bins=range(0, int(max(data['product_wg_ton'])) + 500, 500), color='skyblue', edgecolor='black')
plt.xlabel("Product Weight (tons)")
plt.ylabel("Frequency")
plt.title("Distribution of Product Weight")
plt.show()
```


    
![png](output_8_0.png)
    



```python
# Relationship between numerical variables
# Scatter plot of 'product_wg_ton' vs. 'num_refill_req_l3m'
plt.figure()
plt.scatter(data['num_refill_req_l3m'], data['product_wg_ton'], alpha=0.5)
plt.xlabel("Number of Refills in Last 3 Months")
plt.ylabel("Product Weight (tons)")
plt.title("Product Weight vs. Number of Refills")
plt.show()
```


    
![png](output_9_0.png)
    



```python
# Scatter plot of 'product_wg_ton' vs. 'dist_from_hub'
plt.figure()
plt.scatter(data['dist_from_hub'], data['product_wg_ton'], alpha=0.5)
plt.xlabel("Distance from Hub (Kms)")
plt.ylabel("Product Weight (tons)")
plt.title("Product Weight vs. Distance from Hub")
plt.show()
```


    
![png](output_10_0.png)
    



```python
# Relationship between categorical variables
# Bar plot of 'zone'
plt.figure()
data['zone'].value_counts().plot(kind='bar')
plt.xlabel("Zone")
plt.ylabel("Count")
plt.title("Distribution of Warehouses across Zones")
plt.show()
```


    
![png](output_11_0.png)
    



```python
# Bar plot of 'Location_type'
plt.figure()
data['Location_type'].value_counts().plot(kind='bar')
plt.xlabel("Location Type")
plt.ylabel("Count")
plt.title("Distribution of Warehouses across Location Types")
plt.show()
```


    
![png](output_12_0.png)
    



```python
# Calculate the correlation matrix
correlation_matrix = data[num_vars].corr()
print(correlation_matrix)
```

                                num_refill_req_l3m  dist_from_hub  workers_num   
    num_refill_req_l3m                    1.000000       0.000048    -0.013764  \
    dist_from_hub                         0.000048       1.000000    -0.018565   
    workers_num                          -0.013764      -0.018565     1.000000   
    wh_est_year                           0.027104       0.006658     0.002767   
    storage_issue_reported_l3m           -0.006602      -0.005726    -0.008673   
    wh_breakdown_l3m                      0.000608      -0.000906    -0.017877   
    govt_check_l3m                       -0.003302      -0.000531    -0.003137   
    product_wg_ton                        0.001415      -0.005017    -0.008346   
    
                                wh_est_year  storage_issue_reported_l3m   
    num_refill_req_l3m             0.027104                   -0.006602  \
    dist_from_hub                  0.006658                   -0.005726   
    workers_num                    0.002767                   -0.008673   
    wh_est_year                    1.000000                   -0.628966   
    storage_issue_reported_l3m    -0.628966                    1.000000   
    wh_breakdown_l3m              -0.288174                    0.376986   
    govt_check_l3m                 0.003729                   -0.007602   
    product_wg_ton                -0.604957                    0.986777   
    
                                wh_breakdown_l3m  govt_check_l3m  product_wg_ton  
    num_refill_req_l3m                  0.000608       -0.003302        0.001415  
    dist_from_hub                      -0.000906       -0.000531       -0.005017  
    workers_num                        -0.017877       -0.003137       -0.008346  
    wh_est_year                        -0.288174        0.003729       -0.604957  
    storage_issue_reported_l3m          0.376986       -0.007602        0.986777  
    wh_breakdown_l3m                    1.000000       -0.013273        0.342685  
    govt_check_l3m                     -0.013273        1.000000       -0.008500  
    product_wg_ton                      0.342685       -0.008500        1.000000  
    


```python
# Plot the correlation matrix as a heatmap
plt.figure()
plt.imshow(correlation_matrix, cmap='coolwarm', interpolation='nearest')
plt.colorbar()
plt.xticks(range(len(num_vars)), num_vars, rotation=45)
plt.yticks(range(len(num_vars)), num_vars)
plt.title("Correlation Matrix Heatmap")
plt.show()
```


    
![png](output_14_0.png)
    



```python
# Feature Engineering
data['Age_of_Warehouse'] = pd.Timestamp.now().year - data['wh_est_year']
data['Total_Competitors'] = data['Competitor_in_mkt'] + data['retail_shop_num']
capacity_map = {'Small': 1, 'Mid': 2, 'Large': 3}
data['Numeric_Capacity'] = data['WH_capacity_size'].map(capacity_map)
data['Warehouse_Utilization_Rate'] = data['product_wg_ton'] / data['Numeric_Capacity']
data['Distance_Ratio'] = data['dist_from_hub'] / data['dist_from_hub']
data['Total_Warehouse_Issues'] = data['storage_issue_reported_l3m'] + data['wh_breakdown_l3m']
data['Warehouse_Check_Frequency'] = data['govt_check_l3m'] / data['Age_of_Warehouse']
data['Is_Urban_Location'] = np.where(data['Location_type'] == "Urban", 1, 0)
data['Is_Rural_Location'] = np.where(data['Location_type'] == "Rural", 1, 0)
```


```python
# Drop unnecessary columns if needed
data.drop(columns=['Location_type'], inplace=True)
```


```python
# Check the updated dataset
print(data.head())
```

      Ware_house_ID WH_Manager_ID WH_capacity_size   zone WH_regional_zone   
    0     WH_100000     EID_50000            Small   West           Zone 6  \
    1     WH_100001     EID_50001            Large  North           Zone 5   
    2     WH_100002     EID_50002              Mid  South           Zone 2   
    3     WH_100003     EID_50003              Mid  North           Zone 3   
    4     WH_100004     EID_50004            Large  North           Zone 5   
    
       num_refill_req_l3m  transport_issue_l1y  Competitor_in_mkt   
    0                   3                    1                  2  \
    1                   0                    0                  4   
    2                   1                    0                  4   
    3                   7                    4                  2   
    4                   3                    1                  2   
    
       retail_shop_num  wh_owner_type  ...  product_wg_ton  Age_of_Warehouse   
    0             4651         Rented  ...           17115              14.0  \
    1             6217  Company Owned  ...            5074              14.0   
    2             4306  Company Owned  ...           23137              14.0   
    3             6000         Rented  ...           22115              14.0   
    4             4740  Company Owned  ...           24071              14.0   
    
       Total_Competitors  Numeric_Capacity  Warehouse_Utilization_Rate   
    0               4653                 1                17115.000000  \
    1               6221                 3                 1691.333333   
    2               4310                 2                11568.500000   
    3               6002                 2                11057.500000   
    4               4742                 3                 8023.666667   
    
       Distance_Ratio  Total_Warehouse_Issues  Warehouse_Check_Frequency   
    0             1.0                      18                   1.071429  \
    1             1.0                       7                   1.214286   
    2             1.0                      23                   1.571429   
    3             1.0                      20                   1.928571   
    4             1.0                      24                   1.714286   
    
       Is_Urban_Location Is_Rural_Location  
    0                  1                 0  
    1                  0                 1  
    2                  0                 1  
    3                  0                 1  
    4                  0                 1  
    
    [5 rows x 32 columns]
    


```python
# Predictive modelling
# Sample 20% of the data
sampled_data = data.sample(frac=0.2, random_state=42)
```


```python
# Split the data into training and testing sets (80-20 split)
np.random.seed(42)
train_data = sampled_data.sample(frac=0.8, random_state=42)
test_data = sampled_data.drop(train_data.index)
```


```python
# Split the data into training and testing sets (80-20 split)
np.random.seed(42)
train_data = data.sample(frac=0.8, random_state=42)
test_data = data.drop(train_data.index)
```


```python
# Select the numerical columns for imputation
numerical_columns = ["num_refill_req_l3m", "dist_from_hub", "workers_num", "wh_est_year",
                     "storage_issue_reported_l3m", "wh_breakdown_l3m", "govt_check_l3m", "product_wg_ton"]
```


```python
# Create an instance of the SimpleImputer with the mean strategy
imputer = SimpleImputer(strategy='mean')

# Fit the imputer on the training data
imputer.fit(train_data[numerical_columns])
```




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>SimpleImputer()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">SimpleImputer</label><div class="sk-toggleable__content"><pre>SimpleImputer()</pre></div></div></div></div></div>




```python
# Impute the missing values in the training and testing data
train_data[numerical_columns] = imputer.transform(train_data[numerical_columns])
test_data[numerical_columns] = imputer.transform(test_data[numerical_columns])
```


```python
# Build the linear regression model
model = LinearRegression()
model.fit(train_data[numerical_columns], train_data['product_wg_ton'])
```




<style>#sk-container-id-3 {color: black;background-color: white;}#sk-container-id-3 pre{padding: 0;}#sk-container-id-3 div.sk-toggleable {background-color: white;}#sk-container-id-3 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-3 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-3 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-3 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-3 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-3 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-3 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-3 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-3 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-3 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-3 div.sk-item {position: relative;z-index: 1;}#sk-container-id-3 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-3 div.sk-item::before, #sk-container-id-3 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-3 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-3 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-3 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-3 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-3 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-3 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-3 div.sk-label-container {text-align: center;}#sk-container-id-3 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-3 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" checked><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>




```python
# Get the summary of the model
print("Intercept:", model.intercept_)
print("Coefficients:", model.coef_)
```

    Intercept: -7.024937076494098e-09
    Coefficients: [-1.56763887e-13  6.88338275e-15 -1.25008510e-15  3.50025391e-12
      3.15871981e-12 -5.91089338e-13  1.23182714e-14  1.00000000e+00]
    


```python
# Make predictions on the test data using the model
predictions = model.predict(test_data[numerical_columns])
print(predictions[:5])
```

    [ 7130. 14115. 30063. 12127. 15125.]
    


```python
# Evaluate the model's performance (e.g., using RMSE)
actual_values = test_data['product_wg_ton']
rmse = np.sqrt(mean_squared_error(actual_values, predictions))
print("Root Mean Squared Error (RMSE):", rmse)
```

    Root Mean Squared Error (RMSE): 2.0571884563831152e-11
    


```python
# Data Visualization - Comparing actual vs. predicted values
plt.figure()
plt.scatter(test_data['product_wg_ton'], predictions)
plt.plot(test_data['product_wg_ton'], test_data['product_wg_ton'], color='red', linestyle='dashed')
plt.xlabel("Actual Product Weight (tons)")
plt.ylabel("Predicted Product Weight (tons)")
plt.title("Actual vs. Predicted Product Weight")
plt.show()
```


    
![png](output_28_0.png)
    



```python
# Plot 1: Histogram/Density Plot for 'num_refill_req_l3m'
plt.figure(figsize=(8, 6))
plt.hist(data['num_refill_req_l3m'], bins=range(int(data['num_refill_req_l3m'].min()), int(data['num_refill_req_l3m'].max()) + 1), density=True, color="skyblue", edgecolor="black", alpha=0.7)
sns.kdeplot(data['num_refill_req_l3m'], color="red")
plt.xlabel("Number of Refills in Last 3 Months")
plt.ylabel("Frequency/Density")
plt.title("Distribution of Number of Refills in Last 3 Months")
plt.show()
```


    
![png](output_29_0.png)
    



```python
# Plot 2: Box Plot for 'zone' vs. 'product_wg_ton'
plt.figure(figsize=(10, 6))
sns.boxplot(x="zone", y="product_wg_ton", data=data, palette="pastel")
plt.xlabel("Zone")
plt.ylabel("Product Weight (tons)")
plt.title("Distribution of Product Weight across Zones")
plt.xticks(rotation=45, ha='right')
plt.show()
```


    
![png](output_30_0.png)
    



```python
# Plot 3: Pair Plot for numerical variables
numeric_vars = ["num_refill_req_l3m", "dist_from_hub", "workers_num", "wh_est_year", "storage_issue_reported_l3m", "wh_breakdown_l3m", "govt_check_l3m", "product_wg_ton"]

# Select only the numerical variables for pair plotting
numeric_data = data[numeric_vars]

# Pair plot using the 'pairplot' function from seaborn
sns.pairplot(numeric_data)
plt.show()
```


    
![png](output_31_0.png)
    



```python

```
